<a href="javascript:void(0);" class="btn-transparent defaultDeleteModelBtn text-primary" delete-href="{{ $url }}">
    <i class="bx text-danger bx-trash"></i>
</a>


